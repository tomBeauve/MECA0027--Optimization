

counters = {"f": 0,
            "g": 0,
            "H": 0}
