The code of the optimization methods is located inside the file "HW1.py"
For clarity, the code of the line search methods was moved to the file "lineSearch.py"
Some plotting functions were added to the file "plotOptimizationPath.py" 
The files "counters.py" and "convStudy.py" were created for analysis purposes only