import numpy as np
import matplotlib.pyplot as plt
from getObjFVal import getObjFVal


def plotOptimizationPath(x, functionID):

    lb = -15
    up = 15
    xi = np.arange(lb, up + 0.02, 0.02)
    f = np.zeros((len(xi), len(xi)))

    for i in range(len(xi)):
        for j in range(len(xi)):
            f[j, i] = getObjFVal([xi[i], xi[j]], functionID)

    plt.figure(figsize=(10, 8))
    # plt.title('Optimization Path and Contour Plot')
    plt.xlabel(r'$x$', fontsize=20)
    plt.ylabel(r'$y$', fontsize=20)
    plt.axis([lb, up, lb, up])
    plt.axis('square')
    plt.tick_params(axis='both', which='major', labelsize=16, width=1.5)
    plt.tick_params(axis='both', which='minor', labelsize=16)

    # You can let pyplot choose automatically the contour levels, or you can specify them yourself
    automatic_contour_levels = False

    if automatic_contour_levels:
        # Automatically calculate contour levels
        C = plt.contour(xi, xi, f, cmap='viridis', extend='both')

    else:
        switch_dict = {
            # CHOOSE HERE THE CONTOUR LEVELS
            1: (np.arange(0, 2000, 50), 'Contour for Function 1'),
            2: (np.arange(-20, 250, 5), 'Contour for Function 2'),
            3: (np.arange(-20, 250, 5), 'Contour for Function 2')
        }

        levels, title_text = switch_dict.get(
            functionID, ([], 'Unknown Function'))
        levels = sorted(levels)

        C = plt.contour(xi, xi, f, levels, cmap='viridis', extend='both')

    # Add labels to contour lines
    plt.clabel(C, inline=True, fontsize=8, fmt='%1.1f')

    ind = 1
    for i in range(x.shape[1] - 1):
        # Use different marker styles for optimization path points
        plt.plot(x[0, i], x[1, i], 'o', markersize=9,
                 markerfacecolor='c', markeredgecolor='black')
        plt.plot([x[0, i], x[0, i + 1]],
                 [x[1, i], x[1, i + 1]], 'c', linewidth=2)
        plt.text(x[0, i], x[1, i], str(
            ind - 1), horizontalalignment='center', verticalalignment='center', fontsize=8)
        ind += 1

    # Mark the last point differently
    plt.plot(x[0, -1], x[1, -1], 'o', markersize=9,
             markerfacecolor='red', markeredgecolor='black')
    plt.text(x[0, -1], x[1, -1], str(ind - 1),
             horizontalalignment='center', verticalalignment='center', fontsize=8)
    # plt.savefig('plots\Path_Function' + str(functionID) + 'M2' '.pdf', dpi=300)
    plt.show()


def plotOptiValues(x, functionID):
    plt.figure(figsize=(10, 6))
    plt.xlabel('Iteration (-)')
    plt.ylabel('Objective Function Value (-)')

    obj_values = [getObjFVal(x[:, i], functionID) for i in range(x.shape[1])]

    plt.plot(range(len(obj_values)), obj_values, marker='o', linestyle='-')
    plt.grid(True)
    plt.show()


def plot_function_3D(functionID):
    # Define the domain
    x = np.linspace(-15, 15, 200)
    y = np.linspace(-15, 15, 200)
    X, Y = np.meshgrid(x, y)

    Z = [getObjFVal([Xi, Yi], functionID)
         for Xi, Yi in zip(np.ravel(X), np.ravel(Y))]
    Z = np.array(Z).reshape(X.shape)
    title = f'3D Surface Plot of Function {functionID}'
    # Create the figure
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(111, projection='3d')

    # Plot the surface
    ax.plot_surface(X, Y, Z, cmap='viridis', edgecolor='none')

    # Labels and title
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title(title)

    plt.show()
